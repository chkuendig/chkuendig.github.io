ZILF 0.8 distribution

bin
	Contains ZILF and ZAPF executables.

doc
	Contains documentation for ZILF and ZAPF.

library
	Contains the ZILF interactive fiction library.

sample
	Contains sample games for use with the library.
